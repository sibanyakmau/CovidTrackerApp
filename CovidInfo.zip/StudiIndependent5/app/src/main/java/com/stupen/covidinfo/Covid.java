package com.stupen.covidinfo;

import com.google.gson.annotations.SerializedName;

public class Covid {

    @SerializedName("cases")
    private long totalCases;

    @SerializedName("deaths")
    private long totalDeath;

    @SerializedName("recovered")
    private long totalRecovered;

    public long getTotalCases() {
        return totalCases;
    }

    public void setTotalCases(long totalCases) {
        this.totalCases = totalCases;
    }

    public long getTotalDeath() {
        return totalDeath;
    }

    public void setTotalDeath(long totalDeath) {
        this.totalDeath = totalDeath;
    }

    public long getTotalRecovered() {
        return totalRecovered;
    }

    public void setTotalRecovered(long totalRecovered) {
        this.totalRecovered = totalRecovered;
    }
}
